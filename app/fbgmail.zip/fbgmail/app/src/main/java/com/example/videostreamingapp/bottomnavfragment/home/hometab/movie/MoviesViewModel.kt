package com.example.videostreamingapp.bottomnavfragment.home.hometab.movie

import androidx.lifecycle.ViewModel

class MoviesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}