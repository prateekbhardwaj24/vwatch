package com.example.videostreamingapp.fragments.followers

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.videostreamingapp.*

class ConnectedAdapter: RecyclerView.Adapter<ConnectedAdapter.MyViewHolder>() {
    private var allUsersList: ArrayList<FollowPageModel> = ArrayList()
    private lateinit var context: Context
    private lateinit var connectedViewModel: ConnectedViewModel

    fun addUserOnReferenceScreen(
        context: Context,
        userList: ArrayList<FollowPageModel>,
        connectedViewModel: ConnectedViewModel
    ) {
        this.allUsersList = userList
        this.context = context
        this.connectedViewModel = connectedViewModel
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        var userName: TextView
        var userFullName: TextView
        var followBtn: Button
        var declineBtn: Button

        var imageView: ImageView


        init {
            userName = itemView.findViewById(R.id.uName)
            userFullName = itemView.findViewById(R.id.uFullName)
            followBtn = itemView.findViewById(R.id.followBtn)
            imageView = itemView.findViewById(R.id.uImage)
            declineBtn = itemView.findViewById(R.id.declineBtn)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.follower_page_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = allUsersList.get(position)
        holder.userName.text = data.uname
        holder.userFullName.text = data.name
        Glide.with(context).load(data.imageUri).into(holder.imageView)

        var status = checkStatusAndChangeButton(data)
        if (status.equals("ACCEPT")) {
            holder.declineBtn.visibility = View.VISIBLE
            holder.followBtn.text = status
        } else {
            holder.declineBtn.visibility = View.GONE
            holder.followBtn.text = status
        }

        if (status.equals("SENT")) {
            holder.followBtn.isEnabled = false
        }
        holder.followBtn.setOnClickListener {
            runFunction(status, data.uid,position)

        }
        holder.declineBtn.setOnClickListener {
            runFunction("DECLINE", data.uid, position)
        }

    }


    private fun runFunction(status: String, uid: String, position: Int) {
        if (status.equals("SENT")) {
//request sent by me

        } else if (status.equals("ACCEPT")) {
//someone sent me request so accept or decline
           // followBackRequest(uid,position)
        } else if (status.equals("UNFOLLOW")) {
            unfollowFriend(uid,position)
// we are connected so we can unfollow
        } else if (status.equals("DECLINE")) {
           // declineRequest(uid,position)
        } else {
//we are not connected and unknown
          //  sendFollowRequest(uid)
        }
    }

    private fun declineRequest(uid: String, position: Int) {
        connectedViewModel.declineRequest(uid).observeForever(Observer {
            if (it) {

                notifyItemRemoved(position)
                notifyItemRangeChanged(0,allUsersList.size)
                allUsersList.removeAt(position)
            }
        })
    }

    private fun followBackRequest(uid: String, position: Int) {
        connectedViewModel.followBackRequest(uid).observeForever(Observer {
            if (it) {

//                notifyItemRemoved(position)
//                notifyItemRangeChanged(0,allUsersList.size)
//                allUsersList.removeAt(position)
            }
        })
    }

    private fun unfollowFriend(uid: String, position: Int) {
        connectedViewModel.unFollowFriend(uid).observeForever(Observer {
            allUsersList.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(0,allUsersList.size)

        })
    }


    private fun sendFollowRequest(uid: String) {
        connectedViewModel.sendFollowRequest(uid).observeForever(Observer {

        })
    }

    private fun checkStatusAndChangeButton(data: FollowPageModel): String {
        var result: String
        if (data.friendStatus.equals("sent")) {
            result = "SENT"
        } else if (data.friendStatus.equals("receive")) {
            result = "ACCEPT"
        } else if (data.friendStatus.equals("connected")) {
            result = "UNFOLLOW"
        } else {
            return "FOLLOW"
        }
        return result
    }

    override fun getItemCount(): Int {
        return allUsersList.size
    }
}