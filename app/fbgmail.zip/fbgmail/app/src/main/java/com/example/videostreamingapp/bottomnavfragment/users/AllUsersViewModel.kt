package com.example.videostreamingapp.bottomnavfragment.users

import androidx.lifecycle.ViewModel

class AllUsersViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}