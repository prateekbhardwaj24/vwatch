package com.example.videostreamingapp.ui

import android.os.Bundle
import android.widget.Toast
import com.example.videostreamingapp.R
import com.google.android.youtube.player.YouTubeBaseActivity
import com.google.android.youtube.player.YouTubeInitializationResult
import com.google.android.youtube.player.YouTubePlayer
import com.google.android.youtube.player.YouTubePlayerView

class  RoomActivity : YouTubeBaseActivity() {

    private lateinit var url:String
    private lateinit var videoId:String
    private lateinit var videoDuration:String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_room)

        url = intent.getStringExtra("url")!!
        videoDuration = intent.getStringExtra("videoDuration")!!

        videoId = url!!.split("v=")[1]

        Toast.makeText(this, videoId, Toast.LENGTH_SHORT).show()

        val ytPlayer = findViewById<YouTubePlayerView>(R.id.ytPlayer)

        setAndPlayVideo(ytPlayer)
    }

    private fun setAndPlayVideo(ytPlayer: YouTubePlayerView?) {

        ytPlayer?.initialize(R.string.api_key.toString(), object : YouTubePlayer.OnInitializedListener{

            override fun onInitializationSuccess(
                provider: YouTubePlayer.Provider?,
                player: YouTubePlayer?,
                p2: Boolean
            ) {

                player?.setPlayerStyle(YouTubePlayer.PlayerStyle.CHROMELESS)
                player?.loadVideo(videoId, videoDuration.toInt())

                player?.setPlayerStateChangeListener(object: YouTubePlayer.PlayerStateChangeListener{
                    override fun onLoading() {}
                    override fun onLoaded(p0: String?) {}
                    override fun onAdStarted() {}
                    override fun onVideoStarted() {}
                    override fun onVideoEnded() {
                        player.seekToMillis(0)
                        player.pause()
                    }
                    override fun onError(p0: YouTubePlayer.ErrorReason?) {}

                })


//                player?.loadVideo("ofj1MTXclww")
//                player?.play()
            }

            override fun onInitializationFailure(
                p0: YouTubePlayer.Provider?,
                p1: YouTubeInitializationResult?
            ) {
                Toast.makeText(this@RoomActivity , "Video player Failed" , Toast.LENGTH_SHORT).show()
            }
        })
    }
}