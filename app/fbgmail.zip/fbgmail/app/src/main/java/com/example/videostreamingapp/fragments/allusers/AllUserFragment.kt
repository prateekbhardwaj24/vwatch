package com.example.videostreamingapp.fragments.allusers

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.cardview.widget.CardView
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.videostreamingapp.*
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.friends.DashBoardAdapter
import com.example.videostreamingapp.friends.DashboardViewModel
import com.example.videostreamingapp.databinding.ActivityDashBoardBinding


class AllUserFragment : Fragment() {
    lateinit var dashboardViewModel: DashboardViewModel
    lateinit var dashBoardBinding: ActivityDashBoardBinding
    lateinit var allUserRecyclerView: RecyclerView
    lateinit var followerPageBtn: CardView
    lateinit var sentPageBtn: CardView
    lateinit var requestPageBtn: CardView
    lateinit var dashBoardAdapter: DashBoardAdapter
    var userList:ArrayList<FollowPageModel> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val views:View = inflater.inflate(R.layout.fragment_all_user, container, false)
        dashboardViewModel = ViewModelProvider(
            this
        ).get(DashboardViewModel::class.java)

//        dashBoardBinding = DataBindingUtil.setContentView(requireActivity(),R.layout.activity_dash_board)
//        dashBoardBinding.requestBind = dashboardViewModel


        allUserRecyclerView = views.findViewById(R.id.AllfriendRv)

        allUserRecyclerView.layoutManager = LinearLayoutManager(requireContext())

        dashBoardAdapter = DashBoardAdapter()


        dashboardViewModel.fetchAllUser().observe(requireActivity(), Observer {list->
            list?.let{
                userList = list
                Log.d("check123","final ${list.size}")
                dashBoardAdapter.addUserOnScreen(requireContext(), userList,dashboardViewModel)
            }

        })
        allUserRecyclerView.adapter = dashBoardAdapter



        return views
    }

    override fun onResume() {
        super.onResume()


    }
}