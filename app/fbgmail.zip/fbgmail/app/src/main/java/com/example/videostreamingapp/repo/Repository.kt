package com.example.videostreamingapp.repo

import androidx.lifecycle.MutableLiveData
import com.example.videostreamingapp.model.LiveModel

import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class Repository {

    private val database = Firebase.database.getReference("LiveRoom")

    fun getLiveRooms():MutableLiveData<ArrayList<LiveModel>>{

        val livedata:MutableLiveData<ArrayList<LiveModel>> = MutableLiveData()

        database.addValueEventListener(object : ValueEventListener{
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    val tempList: ArrayList<LiveModel> = ArrayList()
                    for (liveSnap in snapshot.children){
                        val data = liveSnap.getValue(LiveModel::class.java)
                        data?.let {
                            tempList.add(it)
                        }
                    }
                    livedata.value = tempList
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })

        return livedata
    }

}