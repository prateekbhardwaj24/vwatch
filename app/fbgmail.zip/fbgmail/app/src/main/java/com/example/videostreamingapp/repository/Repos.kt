package com.example.videostreamingapp.repository

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.friends.FriendsModel
import com.example.videostreamingapp.messages.MessageData
import com.example.videostreamingapp.username.UserModel
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class repos {

    private val firebaseAuth: FirebaseAuth = FirebaseAuth.getInstance()
    private var firebaseDatabse: FirebaseDatabase = FirebaseDatabase.getInstance()
    private var refNode = Firebase.database.getReference("Users")
    private val messageRef = Firebase.database.getReference("Messages")
    var usersList: ArrayList<UserModel> = ArrayList()
    val list: MutableLiveData<ArrayList<FollowPageModel>> = MutableLiveData()

    fun firebaseSignInWithGmail(googleAuthCredential: AuthCredential): MutableLiveData<Boolean> {
        val authenticateUserLiveData: MutableLiveData<Boolean> = MutableLiveData()

        firebaseAuth.signInWithCredential(googleAuthCredential).addOnCompleteListener { authTask ->
            if (authTask.isSuccessful) {
                var isNewUser = authTask.result?.additionalUserInfo?.isNewUser
                val firebaseUser: FirebaseUser? = firebaseAuth.currentUser


                if (firebaseUser != null) {
//                    val uid = firebaseUser.uid
//                    val name = firebaseUser.displayName
//                    val email = firebaseUser.email
//                    val user = User(uid = uid, name = name, email = email)
//                    user.isNew = isNewUser
                    authenticateUserLiveData.value = true
                    Log.d("123check", "uidname ifff ->>>> $isNewUser")
                } else {
                    Log.d("123check", "uidname elsee2")
                    authenticateUserLiveData.value = false
                }
            }
        }
        return authenticateUserLiveData

    }

    fun insertUserDataInFirebase(userName: String): MutableLiveData<Boolean> {
        val res: MutableLiveData<Boolean> = MutableLiveData()
        val firebaseUser: FirebaseUser? = firebaseAuth.currentUser
        val uid = firebaseUser!!.uid
        val name = firebaseUser.displayName
        val email = firebaseUser.email
        val uname = userName
        val imageUri1 = firebaseUser.photoUrl.toString()
        val user = UserModel(uid = uid, name = name, email = email, uname = uname, imageUri = imageUri1)
        // refNode.child(uid).setValue(user).addOnCompleteListener(object OnC)
        refNode.child(uid).setValue(user).addOnCompleteListener {
            Log.d("123check", "   insertedddd ")
        }
//        refNode.addListenerForSingleValueEvent(object : ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//
//                Log.d("123check", "   inserted ")
//                res.value = true
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                Log.d("123check", "  not inserted ")
//                res.value = false
//            }
//
//        })
        Log.d("123check", "  not entered $imageUri1")
        return res
    }

    fun checkUserType(): MutableLiveData<Boolean> {
        val firebaseUser: FirebaseUser? = firebaseAuth.currentUser
        val res: MutableLiveData<Boolean> = MutableLiveData()

        refNode.child(firebaseUser!!.uid)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        res.value = false
                    } else {
                        res.value = true
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.d("123check", "check canceled")
                }

            })
        return res
    }

    fun getAllUser(): MutableLiveData<ArrayList<FollowPageModel>> {
        var list: MutableLiveData<ArrayList<FollowPageModel>> = MutableLiveData()

        refNode.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val tempLit: ArrayList<FollowPageModel> = ArrayList()
                    var status: String
                    for (postSnapshot in snapshot.children) {
                        if (postSnapshot.child("uid").getValue()!!
                                .equals(firebaseAuth.currentUser!!.uid)
                        ) {
                        } else {
                            if (postSnapshot.child("Friend").child("Receive")
                                    .child(firebaseAuth.currentUser!!.uid).exists()
                            ) {
                                status = "sent"
                            } else if (postSnapshot.child("Friend").child("Sent")
                                    .child(firebaseAuth.currentUser!!.uid).exists()
                            ) {
                                status = "receive"
                            } else if (postSnapshot.child("Friend").child("Connected")
                                    .child(firebaseAuth.currentUser!!.uid).exists()
                            ) {
                                status = "connected"
                            } else {
                                status = "unconnected"
                            }
                            // val userData = postSnapshot.getValue(User::class.java)
                            val email = postSnapshot.child("email").value.toString()
                            val uid = postSnapshot.child("uid").value.toString()
                            val uName = postSnapshot.child("uname").value.toString()
                            val fullName = postSnapshot.child("name").value.toString()
                            val image = postSnapshot.child("imageUri").value.toString()
                            val friendStatus = status

                            val model: FollowPageModel = FollowPageModel(
                                uid = uid,
                                name = fullName,
                                email = email,
                                uname = uName,
                                imageUri = image,
                                friendStatus = friendStatus
                            )
                            model?.let {
                                tempLit.add(model)
                                Log.d("check123", "${model.email}")
                            }
                            // here you can access to name property like university.name
                        }
                    }
                    list.value = tempLit
                    Log.d("check123", "${tempLit.size}")

                }
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
        return list
    }

    fun sendFollowRequest(uid: String): MutableLiveData<Boolean> {
        var res: MutableLiveData<Boolean> = MutableLiveData()
        val friendData: FriendsModel =
            FriendsModel(senderId = firebaseAuth.currentUser!!.uid, recieverId = uid)
        refNode.child(firebaseAuth.currentUser!!.uid).child("Friend").child("Sent").child(uid)
            .setValue(friendData).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    refNode.child(uid).child("Friend").child("Receive")
                        .child(firebaseAuth.currentUser!!.uid).setValue(friendData)
                        .addOnCompleteListener { task1 ->
                            if (task1.isSuccessful) {
                                res.value = true
                            }
                        }
                }

            }
        return res
    }

    fun followBackREquest(uid: String): MutableLiveData<Boolean> {
        var res: MutableLiveData<Boolean> = MutableLiveData()
        refNode.child(firebaseAuth.currentUser!!.uid).child("Friend").child("Connected").child(uid)
            .setValue(uid).addOnCompleteListener { task ->
                if (task.isSuccessful) {

                    refNode.child(uid).child("Friend").child("Connected")
                        .child(firebaseAuth.currentUser!!.uid)
                        .setValue(firebaseAuth.currentUser!!.uid)
                        .addOnCompleteListener { task1 ->
                            if (task1.isSuccessful) {

                                refNode.child(firebaseAuth.currentUser!!.uid).child("Friend")
                                    .child("Receive").child(uid).removeValue()
                                    .addOnCompleteListener { task2 ->
                                        if (task2.isSuccessful) {
                                            refNode.child(uid).child("Friend").child("Sent")
                                                .child(firebaseAuth.currentUser!!.uid).removeValue()
                                                .addOnCompleteListener { task3 ->
                                                    if (task3.isSuccessful) {
                                                        res.value = true
                                                    }
                                                }

                                        }
                                    }

                            }
                        }

                }
            }

        return res
    }

    fun unFollowFriend(uid: String): MutableLiveData<Boolean> {
        var res: MutableLiveData<Boolean> = MutableLiveData()

        refNode.child(firebaseAuth.currentUser!!.uid).child("Friend").child("Connected").child(uid)
            .removeValue().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    refNode.child(uid).child("Friend").child("Connected")
                        .child(firebaseAuth.currentUser!!.uid).removeValue()
                        .addOnCompleteListener { task1 ->
                            if (task1.isSuccessful) {
                                res.value = true
                            }
                        }
                }
            }

        return res
    }

    fun declineRequest(uid: String): MutableLiveData<Boolean> {
        var res: MutableLiveData<Boolean> = MutableLiveData()

        refNode.child(firebaseAuth.currentUser!!.uid).child("Friend").child("Receive").child(uid)
            .removeValue().addOnCompleteListener { task1 ->
                if (task1.isSuccessful) {
                    refNode.child(uid).child("Friend").child("Sent")
                        .child(firebaseAuth.currentUser!!.uid).removeValue()
                        .addOnCompleteListener { task2 ->
                            if (task2.isSuccessful) {
                                res.value = true
                            }
                        }

                }
            }


        return res
    }

    fun getReferencePageUserAccToTitle(title: String?): MutableLiveData<ArrayList<String>> {
        var list: MutableLiveData<ArrayList<String>> = MutableLiveData()
        var tempLitIds: ArrayList<String> = ArrayList()

        var newTitle: String = "Sent"
        var newStatus: String = "sent"


        if (title.equals("follower")) {
            newTitle = "Connected"
            newStatus = "connected"
        } else if (title.equals("request")) {
            newTitle = "Receive"
            newStatus = "receive"
        } else if (title.equals("sent")) {
            newTitle = "Sent"
            newStatus = "sent"
        }
        Log.d("llll12", "title: $newStatus")

        var newNode = refNode.child(firebaseAuth.currentUser!!.uid).child("Friend").child(newTitle)

        newNode.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                if (snapshot.exists()) {
                    Log.d("llll12", "snapshot: exits")

                    for (postSnapShot in snapshot.children) {
                        val ids = postSnapShot.key
                        if (ids != null) {
                            tempLitIds.add(ids)
                        }
                    }
                    list.value = tempLitIds
                }
            }

            override fun onCancelled(error: DatabaseError) {

            }

        })



        return list
    }

    fun fetchUserData(
        tempLitIds: ArrayList<String>,
        newStatus: String
    ): MutableLiveData<ArrayList<FollowPageModel>> {
        var tempLit: ArrayList<FollowPageModel> = ArrayList()
        var status = "sent"


        if (newStatus.equals("follower")) {

            status = "connected"
        } else if (newStatus.equals("request")) {

            status = "receive"
        } else if (newStatus.equals("sent")) {
            status = "sent"
        }

        for (userId in tempLitIds) {
            Log.d("llll12", "tempsize: ${tempLitIds.size}")
            refNode.child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(postSnapshot1: DataSnapshot) {
                    val email = postSnapshot1.child("email").value.toString()
                    val uid = postSnapshot1.child("uid").value.toString()
                    val uName = postSnapshot1.child("uname").value.toString()
                    val fullName = postSnapshot1.child("name").value.toString()
                    val image = postSnapshot1.child("imageUri").value.toString()
                    val friendStatus = status
                    Log.d("llll12", "email: $email")
                    val model: FollowPageModel = FollowPageModel(
                        uid = uid,
                        name = fullName,
                        email = email,
                        uname = uName,
                        imageUri = image,
                        friendStatus = friendStatus
                    )
                    model?.let {
                        tempLit.add(model)
                        list.postValue(tempLit)
                        Log.d("llll12", "e => ${model.email}")
                        Log.d("llll12", "listSizeinsidelast: ${tempLit.size}")

                    }
                }

                override fun onCancelled(error: DatabaseError) {

                }

            })

        }

        Log.d("llll12", "listSizeee: ${list}")

        return list
    }

    fun sendMessageToRoomNode(message: String): MutableLiveData<Boolean> {
        val result: MutableLiveData<Boolean> = MutableLiveData()
        val time = System.currentTimeMillis().toString()
        val data: MessageData = MessageData(
            message,
            time,
            firebaseAuth.currentUser!!.uid,
            firebaseAuth.currentUser!!.displayName.toString(),
            firebaseAuth.currentUser!!.photoUrl.toString()
        )
        messageRef.child("roomId").child(time).setValue(data).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                result.value = true
                Log.d("checkValue123", "message sent success in db")
            } else {
                Log.d("checkValue123", "message sent unsuccess in db")
            }

        }
        return result
    }

    fun fetchMessagesFromRootNode(roomid: String): MutableLiveData<ArrayList<MessageData>> {
        val result: MutableLiveData<ArrayList<MessageData>> = MutableLiveData()
        val messagList: ArrayList<MessageData> = ArrayList()

//        messageRef.child(roomid).addListenerForSingleValueEvent(object : ValueEventListener {
//            override fun onDataChange(snapshot: DataSnapshot) {
//
//                if (snapshot.exists()) {
//
//                    for (postSnap in snapshot.children) {
//                        val userData = postSnap.getValue(MessageData::class.java)
//                        userData?.let {
//                            messagList.add(it)
//                            result.postValue(messagList)
//                        }
//                    }
//
//                    //start
//
//                    ///end
//
//                } else {
//
//                }
//            }
//
//            override fun onCancelled(error: DatabaseError) {
//                TODO("Not yet implemented")
//            }
//        })


        messageRef.child(roomid).addChildEventListener(object :ChildEventListener{
            override fun onChildAdded(snapshot: DataSnapshot, previousChildName: String?) {

                if (snapshot.exists()) {


                    val userData = snapshot.getValue(MessageData::class.java)
                    Log.d("klklkl","$userData")
                    userData?.let {
                         messagList.add(it)
                        result.postValue(messagList)

                    }



                } else {

                }
            }

            override fun onChildChanged(snapshot: DataSnapshot, previousChildName: String?) {
                TODO("Not yet implemented")
            }

            override fun onChildRemoved(snapshot: DataSnapshot) {
                TODO("Not yet implemented")
            }

            override fun onChildMoved(snapshot: DataSnapshot, previousChildName: String?) {
                TODO("Not yet implemented")
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }

        })


        return result
    }
}