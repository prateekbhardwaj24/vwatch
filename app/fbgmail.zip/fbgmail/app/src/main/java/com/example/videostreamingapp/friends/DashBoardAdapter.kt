package com.example.videostreamingapp.friends

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.R
import de.hdodenhof.circleimageview.CircleImageView

class DashBoardAdapter : RecyclerView.Adapter<DashBoardAdapter.MyViewHolder>() {
    private var allUsersList: ArrayList<FollowPageModel> = ArrayList()
    private lateinit var context: Context
    private lateinit var dashboardViewModel: DashboardViewModel

    fun addUserOnScreen(
        context: Context,
        userList: ArrayList<FollowPageModel>,
        dashboardViewModel: DashboardViewModel
    ) {
        this.allUsersList = userList
        this.context = context
        this.dashboardViewModel = dashboardViewModel
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var userName: TextView
        var userFullName: TextView
        var followBtn: Button
        var declineBtn: Button

        var imageView: CircleImageView


        init {
            userName = itemView.findViewById(R.id.uName)
            userFullName = itemView.findViewById(R.id.uFullName)
            followBtn = itemView.findViewById(R.id.followBtn)
            imageView = itemView.findViewById(R.id.uImage)
            declineBtn = itemView.findViewById(R.id.declineBtn)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.follower_page_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = allUsersList.get(position)
        holder.userName.text = data.uname
        holder.userFullName.text = data.name
        Glide.with(context).load(data.imageUri).into(holder.imageView)

        var status = checkStatusAndChangeButton(data)
        setButtonText(status,holder)

        holder.followBtn.setOnClickListener {
            runFunction(status, data.uid,position,holder)

        }
        holder.declineBtn.setOnClickListener {
            runFunction("DECLINE", data.uid, position, holder)
        }

    }

    private fun setButtonText(status: String, holder: MyViewHolder) {
        if (status.equals("ACCEPT")) {
            holder.declineBtn.visibility = View.VISIBLE
            holder.followBtn.text = status
            holder.followBtn.isEnabled = true
        } else {
            holder.declineBtn.visibility = View.GONE
            holder.followBtn.text = status
            holder.followBtn.isEnabled = true
        }

        if (status.equals("SENT")){
            holder.followBtn.isEnabled = false
        }
    }

    private fun runFunction(status: String, uid: String, position: Int, holder: MyViewHolder) {
        if (status.equals("SENT")) {
//request sent by me

        } else if (status.equals("ACCEPT")) {
//someone sent me request so accept or decline
            followBackRequest(uid,position,holder,status)
        } else if (status.equals("UNFOLLOW")) {
            unfollowFriend(uid,position,holder,status)
// we are connected so we can unfollow
        } else if(status.equals("DECLINE")){
            declineRequest(uid,position,holder,status)
        }else {
//we are not connected and unknown
            sendFollowRequest(uid,position,holder,status)
        }
    }

    private fun declineRequest(uid: String, position: Int, holder: MyViewHolder, status: String) {
        dashboardViewModel.declineRequest(uid).observeForever(Observer {
//notifyItemChanged(position)
           // setButtonText(status,holder)
        })
    }

    private fun followBackRequest(uid: String, position: Int, holder: MyViewHolder, status: String) {
        dashboardViewModel.followBackRequest(uid).observeForever(Observer {
//            notifyItemChanged(position)
           // setButtonText(status,holder)
        })
    }

    private fun unfollowFriend(uid: String, position: Int, holder: MyViewHolder, status: String) {
        dashboardViewModel.unFollowFriend(uid).observeForever(Observer {
//            notifyItemChanged(position)
           // setButtonText(status,holder)
        })
    }


    private fun sendFollowRequest(uid: String, position: Int, holder: MyViewHolder, status: String) {
        dashboardViewModel.sendFollowRequest(uid).observeForever(Observer {

//            notifyItemChanged(position)
          //  setButtonText(status,holder)

        })
    }

    override fun getItemCount(): Int {
        return allUsersList.size
    }

    private fun checkStatusAndChangeButton(data: FollowPageModel): String {
        var result: String
        if (data.friendStatus.equals("sent")) {
            result = "SENT"
        } else if (data.friendStatus.equals("receive")) {
            result = "ACCEPT"
        } else if (data.friendStatus.equals("connected")) {
            result = "UNFOLLOW"
        } else {
            return "FOLLOW"
        }
        return result
    }
}