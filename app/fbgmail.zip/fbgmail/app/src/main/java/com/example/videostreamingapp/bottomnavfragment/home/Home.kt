package com.example.videostreamingapp.bottomnavfragment.home

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager.widget.ViewPager
import com.example.videostreamingapp.R
import com.example.videostreamingapp.bottomnavfragment.home.hometab.live.LiveAdapter
import com.example.videostreamingapp.bottomnavfragment.home.hometab.live.LiveViewModel
import com.example.videostreamingapp.model.LiveModel

import com.google.android.material.tabs.TabLayout

class Home : Fragment() {

    private lateinit var viewModel: LiveViewModel

    private lateinit var recycler : RecyclerView
    private lateinit var arrayList: ArrayList<LiveModel>
    private lateinit var adapter: LiveAdapter
    companion object {
        fun newInstance() = Home()
    }



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        val root:View = inflater.inflate(R.layout.home_fragment, container, false)

        viewModel = ViewModelProvider(this)[LiveViewModel::class.java]
        recycler = root.findViewById(R.id.live_recycler)
        recycler.layoutManager = GridLayoutManager(requireContext(), 2)
//        recycler.addItemDecoration(DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL))

        getLiveData()
        arrayList = arrayListOf()

        adapter = LiveAdapter(requireContext())
        recycler.adapter = adapter
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
    }

    private fun getLiveData() {
        viewModel.getLiveRooms().observe(requireActivity(), Observer { list->
            list?.let {
                arrayList = list

                adapter.updateLiveRoom(arrayList)
            }
        })
    }




}