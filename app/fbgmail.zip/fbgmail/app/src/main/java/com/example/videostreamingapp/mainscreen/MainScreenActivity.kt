package com.example.videostreamingapp.mainscreen

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import com.example.videostreamingapp.R
import com.example.videostreamingapp.databinding.ActivityMainScreenBinding
import com.example.videostreamingapp.bottomnavfragment.createroom.CreateRoom
import com.example.videostreamingapp.bottomnavfragment.home.Home
import com.example.videostreamingapp.bottomnavfragment.notification.Notification
import com.example.videostreamingapp.bottomnavfragment.profile.Profile
import com.example.videostreamingapp.bottomnavfragment.users.AllUsers


class MainScreenActivity : AppCompatActivity() {

    lateinit var mainBinding : ActivityMainScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_main_screen)

        mainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main_screen)

        val home = Home()
        val profile = Profile()
        val createRoom = CreateRoom()
        val notification = Notification()
        val users = AllUsers()

        setCurrentFragment(home)

        mainBinding.bottomNavigation.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.home->setCurrentFragment(home)
                R.id.roommates->setCurrentFragment(users)
                R.id.createroom->setCurrentFragment(createRoom)
                R.id.notification->setCurrentFragment(notification)
                R.id.profile->setCurrentFragment(profile)

            }
            true
        }

    }

    private fun setCurrentFragment(fragment: Fragment) {

        supportFragmentManager.beginTransaction().apply {
            replace(R.id.fl_wrapper, fragment)
            commit()
        }

    }
}