package com.example.videostreamingapp.messages

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.videostreamingapp.R
import de.hdodenhof.circleimageview.CircleImageView

class MessageAdpter : RecyclerView.Adapter<MessageAdpter.MyViewHolder>() {
    private var allMessageList: ArrayList<MessageData> = ArrayList()
    private lateinit var context: Context
    private lateinit var messageViewModel: MessageViewModel


    fun setAllMessages(
        context: Context,
        messagelist: ArrayList<MessageData>,
        messageViewModel: MessageViewModel
    ) {
        this.allMessageList = messagelist
        this.context = context
        this.messageViewModel = messageViewModel
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
         var perosnImage: CircleImageView
         var messageText: TextView
         var senderName: TextView

        init {
            perosnImage = itemView.findViewById(R.id.messageImg)
            messageText = itemView.findViewById(R.id.messageTextView)
            senderName = itemView.findViewById(R.id.messageSenderName)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.message_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = allMessageList.get(position)
        holder.messageText.text = data.message
        holder.senderName.text = data.sendName

        Glide.with(context).load(data.sendImage).into(holder.perosnImage)
    }

    override fun getItemCount(): Int {
        return allMessageList.size
    }


}