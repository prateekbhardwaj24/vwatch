package com.example.videostreamingapp.model

data class LiveModel(
    var title:String?=null,
    var views:String?=null,
    var duration:String? = null,
    var category:String? = null,
    var url:String? = null,
    var currentDuration:String? = null
)
