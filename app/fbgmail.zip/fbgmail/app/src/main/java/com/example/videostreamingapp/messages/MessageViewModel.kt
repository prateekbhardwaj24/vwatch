package com.example.videostreamingapp.messages

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.videostreamingapp.repository.repos

class MessageViewModel:ViewModel() {
    private val repository: repos = repos()

    fun sendMessageToRoomNode(message:String):MutableLiveData<Boolean>{
        return repository.sendMessageToRoomNode(message)
    }

    fun fetchMessageFromRoomNode(roomid: String):MutableLiveData<ArrayList<MessageData>> {
        return repository.fetchMessagesFromRootNode(roomid)
    }
}