package com.example.videostreamingapp.bottomnavfragment.home.hometab.live

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.videostreamingapp.R
import com.example.videostreamingapp.model.LiveModel
import com.example.videostreamingapp.ui.RoomActivity
import com.google.android.youtube.player.*

class LiveAdapter(val context: Context): RecyclerView.Adapter<LiveAdapter.myViewHolder>() {

    private val arrayList:ArrayList<LiveModel> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LiveAdapter.myViewHolder {
        val root = LayoutInflater.from(parent.context).inflate(R.layout.video_thumnail_layout,parent,false)
        return myViewHolder(root)
    }

    override fun onBindViewHolder(holder: LiveAdapter.myViewHolder, position: Int) {

        val onThumbnailLoadedListener : YouTubeThumbnailLoader.OnThumbnailLoadedListener = object : YouTubeThumbnailLoader.OnThumbnailLoadedListener{
            override fun onThumbnailLoaded(p0: YouTubeThumbnailView?, p1: String?) {

            }

            override fun onThumbnailError(
                p0: YouTubeThumbnailView?,
                p1: YouTubeThumbnailLoader.ErrorReason?
            ) {

            }

        }

        holder.bind(arrayList[position], onThumbnailLoadedListener)
    }

    fun updateLiveRoom(updateList:ArrayList<LiveModel>){
        arrayList.clear()
        arrayList.addAll(updateList)
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return arrayList.size
    }

    inner class myViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(
            data: LiveModel,
            onThumbnailLoadedListener: YouTubeThumbnailLoader.OnThumbnailLoadedListener
        ){
            itemView.findViewById<TextView>(R.id.viewsTv).text = data.views
            itemView.findViewById<TextView>(R.id.durationTv).text = data.duration
            itemView.findViewById<TextView>(R.id.titleTv).text = data.title
            itemView.findViewById<TextView>(R.id.categoryTv).text = data.category
            var thumbnail = itemView.findViewById<YouTubeThumbnailView>(R.id.ytPlayer)

            setThumbnail(thumbnail, data, onThumbnailLoadedListener)

            itemView.setOnClickListener(View.OnClickListener {
                val intent = Intent(context, RoomActivity::class.java)
                intent.putExtra("url", data.url)
                intent.putExtra("videoDuration", data.currentDuration)
                context.startActivity(intent)
            })

        }
    }

    private fun setThumbnail(
        thumbnail: YouTubeThumbnailView,
        data: LiveModel,
        onThumbnailLoadedListener: YouTubeThumbnailLoader.OnThumbnailLoadedListener
    ) {
        var videoId:String = data.url!!.split("v=")[1]

        thumbnail.initialize(R.string.api_key.toString(), object : YouTubeThumbnailView.OnInitializedListener{
            override fun onInitializationSuccess(
                p0: YouTubeThumbnailView?,
                p1: YouTubeThumbnailLoader?
            ) {
                p1?.setVideo(videoId)
                p1?.setOnThumbnailLoadedListener(onThumbnailLoadedListener)
            }

            override fun onInitializationFailure(
                p0: YouTubeThumbnailView?,
                p1: YouTubeInitializationResult?
            ) {

            }

        })
    }

}