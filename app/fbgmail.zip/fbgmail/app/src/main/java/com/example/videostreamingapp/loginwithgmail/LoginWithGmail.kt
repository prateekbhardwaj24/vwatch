package com.example.videostreamingapp.loginwithgmail

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.videostreamingapp.R
import com.example.videostreamingapp.username.UserNameActivity
import com.example.videostreamingapp.databinding.ActivityLoginWithGmailBinding
import com.example.videostreamingapp.mainscreen.MainScreenActivity
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInAccount
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.SignInButton
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.tasks.Task
import com.google.firebase.auth.AuthCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class LoginWithGmail : AppCompatActivity() {
    private lateinit var mAuth: FirebaseAuth
    private lateinit var googleSignClient: GoogleSignInClient
    private lateinit var signInBtn: SignInButton
    lateinit var loginViewModel: LoginViewModel
    lateinit var loginBinding:ActivityLoginWithGmailBinding
    companion object {
        private const val RC_SIGN_IN = 100
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_with_gmail)

        loginViewModel = ViewModelProvider(
            this
        ).get(LoginViewModel::class.java)

        loginBinding = DataBindingUtil.setContentView(this, R.layout.activity_login_with_gmail)



       // loginBinding.gmailviewbind = loginViewModel
        signInBtn = findViewById(R.id.sign_in_button)

        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken("241293798293-arhnd5i63n0c7sk0oqni2j3ehvripc4v.apps.googleusercontent.com")

            .requestEmail()
            .build()

        googleSignClient = GoogleSignIn.getClient(this, gso)

        mAuth = FirebaseAuth.getInstance()

        loginBinding.signInButton.setOnClickListener {
            signIn()
        }
    }

    private fun signIn() {
        val signInIntent = googleSignClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)



    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
               val exception = task.exception
            if (task.isSuccessful) {
                try {
                    // Google Sign In was successful, authenticate with Firebase
                    val account = task.getResult(ApiException::class.java)!!
                     Log.d("123check", "firebaseAuthWithGoogleiddd:" + account.id)
                     firebaseAuthWithGoogle(account.idToken!!)

                } catch (e: ApiException) {
                    // Google Sign In failed, update UI appropriately
                     Log.d("123check", "Google sign in failed", e)
                }
            } else {
                Log.w("123check", "el-=> "+exception.toString())
            }

        }
    }

    private fun handleSignInResult(task: Task<GoogleSignInAccount>?) {
        try {
            val acct = GoogleSignIn.getLastSignedInAccount(this)
            if (acct != null){
                Log.d("123check", "signInWithCredential:success")

                val intent = Intent(this, MainScreenActivity::class.java)
                startActivity(intent)
            }else{
                Log.d("123check", "signInWithCredential: unnsuccess")

            }
        }catch (e: ApiException){
            Log.d("123check", "signInWithCredential:"+e)

        }
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        mAuth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d("123check", "signInWithCredential:success")
                    val user = mAuth.currentUser
                    ////  updateUI(user)

                    //check user is old or new
                    loginViewModel.checkUserOldNew().observe(this, Observer {
                        if (it){
                            launchUserNameActivity()
                            Log.d("123check", "check user is : " + it)
                        }else{
                            Log.d("123check", "check user is : " + it)
                            directlyLogin(credential)
                        }
                    })

                    //loginViewModel.signInWithGoogle(credential)

                } else {
                    // If sign in fails, display a message to the user.
                    Log.d("123check", "signInWithCredential:failure", task.exception)
                    //  updateUI(null)
                }
            }
    }

    private fun launchUserNameActivity() {

        val intent = Intent(this, UserNameActivity::class.java)
        startActivity(intent)
    }

    private fun directlyLogin(credential: AuthCredential) {
        loginViewModel.signInWithGoogle(credential).observe(this, Observer {
            if (it){
                Log.d("123check", "Auth: " + it)
                val intent = Intent(this, MainScreenActivity::class.java)
                startActivity(intent)
            }else{
                Log.d("123check", "Auth: " +"blnk")
            }

        })

    }
}