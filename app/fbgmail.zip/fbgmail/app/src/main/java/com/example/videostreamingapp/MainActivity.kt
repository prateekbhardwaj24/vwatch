package com.example.videostreamingapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.videostreamingapp.loginwithgmail.LoginWithGmail
import com.example.videostreamingapp.mainscreen.MainScreenActivity
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity() {

    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mAuth = FirebaseAuth.getInstance()
        val user = mAuth.currentUser



        if (user != null) {
            val mainActivityIntent = Intent(this, MainScreenActivity::class.java)
            startActivity(mainActivityIntent)
        } else {
            val loginActivityIntent = Intent(this, LoginWithGmail::class.java)
            startActivity(loginActivityIntent)
        }




    }
}