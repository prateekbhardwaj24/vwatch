package com.example.videostreamingapp.fragments.sent

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.repository.repos

class SentViewModel:ViewModel() {
    private val repository: repos = repos()


    fun sendFollowRequest(uid: String): MutableLiveData<Boolean> {
        return repository.sendFollowRequest(uid)
    }

    fun fetchListAccordingToTitle(title: String?): MutableLiveData<ArrayList<String>> {
        return repository.getReferencePageUserAccToTitle(title)
    }

    fun fetchUserDataFromId(list: ArrayList<String>, title: String): MutableLiveData<ArrayList<FollowPageModel>> {
        return  repository.fetchUserData(list, title)
    }

    fun followBackRequest(uid: String): MutableLiveData<Boolean> {
        return repository.followBackREquest(uid)
    }

    fun unFollowFriend(uid: String): MutableLiveData<Boolean> {
        return repository.unFollowFriend(uid)
    }

    fun declineRequest(uid: String): MutableLiveData<Boolean> {
        return repository.declineRequest(uid)
    }

}