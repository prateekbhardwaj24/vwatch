package com.example.videostreamingapp.fragments.sent

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.videostreamingapp.*
import com.example.videostreamingapp.fragments.followers.FollowPageModel

class SentFragment : Fragment() {
    lateinit var referenceRv: RecyclerView
    lateinit var sentAdapter: SentAdapter
    lateinit var sentViewModel: SentViewModel
    var userList:ArrayList<FollowPageModel> = ArrayList()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val views:View =  inflater.inflate(R.layout.fragment_sent, container, false)


        sentViewModel = ViewModelProvider(
            this
        ).get(SentViewModel::class.java)


        referenceRv = views.findViewById(R.id.sentRv)

        referenceRv.layoutManager = LinearLayoutManager(requireContext())

        sentAdapter = SentAdapter()

        val swipeRefreshLayout = views.findViewById<SwipeRefreshLayout>(R.id.sentSwipeReferes)
        swipeRefreshLayout.setOnRefreshListener{

            // This line is important as it explicitly refreshes only once
            // If "true" it implicitly refreshes forever
            userList.clear()
            getListAccToTitle("sent",swipeRefreshLayout)
            referenceRv.adapter = sentAdapter

        }
        getListAccToTitle("sent", swipeRefreshLayout)
        referenceRv.adapter = sentAdapter


        return views
    }


    private fun getListAccToTitle(title: String?, swipeRefreshLayout: SwipeRefreshLayout){
        if (userList.isNullOrEmpty()){
            swipeRefreshLayout.isRefreshing = false
        }
        sentViewModel.fetchListAccordingToTitle(title).observe(requireActivity(), Observer {
                list->

            list?.let {
//                userList.addAll(list)
                // referencePageAdapter.addUserOnReferenceScreen(this,list,dashboardViewModel)
                sentViewModel.fetchUserDataFromId(list, title!!).observe(requireActivity(), Observer {
                        dataList->
                    userList = dataList
                    sentAdapter.addUserOnReferenceScreen(requireContext(),userList,sentViewModel)
                    referenceRv.adapter = sentAdapter
                    swipeRefreshLayout.isRefreshing = false

                })
            }
        })
    }
}