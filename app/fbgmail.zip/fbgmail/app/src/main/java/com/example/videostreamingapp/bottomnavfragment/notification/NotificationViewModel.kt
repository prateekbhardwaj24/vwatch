package com.example.videostreamingapp.bottomnavfragment.notification

import androidx.lifecycle.ViewModel

class NotificationViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}