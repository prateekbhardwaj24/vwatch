package com.example.videostreamingapp.fragments.followers

data class FollowPageModel(
    val uid: String = "",
    val name: String? = "",
    val email: String? = "",
    val uname: String? = "",
    val imageUri: String = "",
    val friendStatus: String = "",
)
