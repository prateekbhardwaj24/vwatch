package com.example.videostreamingapp.bottomnavfragment.home

import android.content.Context
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.videostreamingapp.bottomnavfragment.home.hometab.live.Live
import com.example.videostreamingapp.bottomnavfragment.home.hometab.movie.Movies
import com.example.videostreamingapp.bottomnavfragment.home.hometab.videos.Video
import com.example.videostreamingapp.bottomnavfragment.home.hometab.webseries.WebSeries

class homeviewpageradapter(private val myContext: Context, fm: FragmentManager, internal var totalTabs: Int) : FragmentPagerAdapter(fm) {
    override fun getCount(): Int {
        return totalTabs
    }

    override fun getItem(position: Int): Fragment {
        return when (position) {
            0 -> Live()
            1 -> Movies()
            2 -> WebSeries()
            3 -> Video()
            else -> Live()
        }

    }
}