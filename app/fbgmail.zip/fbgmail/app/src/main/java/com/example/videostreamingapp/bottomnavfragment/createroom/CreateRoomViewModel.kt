package com.example.videostreamingapp.bottomnavfragment.createroom

import androidx.lifecycle.ViewModel

class CreateRoomViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}