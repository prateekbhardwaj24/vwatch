package com.example.videostreamingapp.friends

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentPagerAdapter
import com.example.videostreamingapp.fragments.allusers.AllUserFragment
import com.example.videostreamingapp.fragments.followers.ConnectedFragment
import com.example.videostreamingapp.fragments.received.RequestFragment
import com.example.videostreamingapp.fragments.sent.SentFragment

class ViewPagerFragmentAdapter(fm:FragmentManager) : FragmentPagerAdapter(fm) {
    override fun getCount(): Int {
        return 4;
    }

    override fun getItem(position: Int): Fragment {
        when(position) {
            0 -> {
                return AllUserFragment()
            }
            1 -> {
                return SentFragment()
            }
            2 -> {
                return RequestFragment()
            }
            3->{
                return ConnectedFragment()
            }
            else -> {
                return ConnectedFragment()
            }
        }
    }

    override fun getPageTitle(position: Int): CharSequence? {
        when(position) {
            0 -> {
                return "All users"
            }
            1 -> {
                return "sent"
            }
            2 -> {
                return "receive"
            }
            3 ->{
                return "folllowers"
            }
        }
        return super.getPageTitle(position)
    }
}