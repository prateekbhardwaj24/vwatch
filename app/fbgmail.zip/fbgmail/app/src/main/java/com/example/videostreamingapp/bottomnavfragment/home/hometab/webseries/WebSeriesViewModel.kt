package com.example.videostreamingapp.bottomnavfragment.home.hometab.webseries

import androidx.lifecycle.ViewModel

class WebSeriesViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}