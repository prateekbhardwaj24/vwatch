package com.example.videostreamingapp.friends

data class FriendsModel(
    val senderId: String = "",
    val recieverId: String? = "",
)
