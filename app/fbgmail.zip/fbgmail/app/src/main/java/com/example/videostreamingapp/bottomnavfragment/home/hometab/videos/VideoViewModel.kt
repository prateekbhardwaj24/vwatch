package com.example.videostreamingapp.bottomnavfragment.home.hometab.videos

import androidx.lifecycle.ViewModel

class VideoViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}