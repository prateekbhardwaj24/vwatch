package com.example.videostreamingapp.friends

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.repository.repos

class DashboardViewModel(): ViewModel() {
    private val repository: repos = repos()


    fun fetchAllUser():MutableLiveData<ArrayList<FollowPageModel>>{
        return repository.getAllUser()
    }
    fun sendFollowRequest(uid: String):MutableLiveData<Boolean>{
        return repository.sendFollowRequest(uid)
    }

    fun followBackRequest(uid: String): MutableLiveData<Boolean> {
return repository.followBackREquest(uid)
    }

    fun unFollowFriend(uid: String): MutableLiveData<Boolean> {
return repository.unFollowFriend(uid)
    }

    fun declineRequest(uid: String): MutableLiveData<Boolean> {
return repository.declineRequest(uid)
    }

    fun fetchListAccordingToTitle(title: String?): MutableLiveData<ArrayList<String>> {
        return repository.getReferencePageUserAccToTitle(title)
    }

    fun fetchUserDataFromId(list: ArrayList<String>, title: String): MutableLiveData<ArrayList<FollowPageModel>> {
return  repository.fetchUserData(list, title)
    }
}