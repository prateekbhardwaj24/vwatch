package com.example.videostreamingapp.friends

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager2.widget.ViewPager2
import com.example.videostreamingapp.R
import com.example.videostreamingapp.messages.MessageActivity
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class DashBoardActivity : AppCompatActivity() {
    //    lateinit var dashboardViewModel: DashboardViewModel
//    lateinit var dashBoardBinding: ActivityDashBoardBinding
//    lateinit var allUserRecyclerView:RecyclerView
//    lateinit var followerPageBtn:CardView
//    lateinit var sentPageBtn:CardView
//    lateinit var requestPageBtn:CardView
//    lateinit var dashBoardAdapter: DashBoardAdapter
//    var userList:ArrayList<FollowPageModel> = ArrayList()
    lateinit var messgeBtn: FloatingActionButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dash_board)

        val tabLayout = findViewById<TabLayout>(R.id.pagerTabsLayout)
        val viewPager = findViewById<ViewPager2>(R.id.slidingViewPager)

//
//        val pagerAdapter = ViewPagerFragmentAdapter(
//            supportFragmentManager,
//            lifecycle
//        )

//        viewPager.adapter = pagerAdapter
//        messgeBtn = findViewById(R.id.messageFloatingBtn)
//        messgeBtn.setOnClickListener {
//            val intent = Intent(this, MessageActivity::class.java)
//            startActivity(intent)
//        }

//        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
//            when (position) {
//
//                0 -> {
//                    tab.text = "All users"
//                }
//                1 -> {
//                    tab.text = "Sent"
//                }
//                2 -> {
//                    tab.text = "Received"
//                }
//                3 -> {
//                    tab.text = "followers"
//                }
//            }
//        }.attach()

//        dashboardViewModel = ViewModelProvider(
//            this
//        ).get(DashboardViewModel::class.java)
//
//        dashBoardBinding = DataBindingUtil.setContentView(this,R.layout.activity_dash_board)
//        dashBoardBinding.requestBind = dashboardViewModel
//
//
//        allUserRecyclerView = findViewById(R.id.friendRv)
//        followerPageBtn = findViewById(R.id.followerCardBtn)
//        requestPageBtn =  findViewById(R.id.requestCardBtn)
//        sentPageBtn = findViewById(R.id.sentCardBtn)
//
//        allUserRecyclerView.layoutManager = LinearLayoutManager(this)
//
//        dashBoardAdapter = DashBoardAdapter()
//        allUserRecyclerView.adapter = dashBoardAdapter
//
//        dashboardViewModel.fetchAllUser().observe(this, Observer {list->
//            list?.let{
//                userList = list
//                Log.d("check123","final ${list.size}")
//                dashBoardAdapter.addUserOnScreen(this, userList,dashboardViewModel)
//            }
//
//        })

//        //click action on follower sent and request card to send user on respective page
//        followerPageBtn.setOnClickListener {
//           sendUserToReferncePage("follower")
//        }
//        requestPageBtn.setOnClickListener {
//            sendUserToReferncePage("request")
//        }
//        sentPageBtn.setOnClickListener {
//            sendUserToReferncePage("sent")
//        }


    }

//    private fun sendUserToReferncePage(s: String) {
//        val intent = Intent(this,ReferencePageActivity::class.java)
//        intent.putExtra("buttonTitle",s)
//        startActivity(intent)
//    }
}