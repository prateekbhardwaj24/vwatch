package com.example.videostreamingapp.bottomnavfragment.users

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.viewpager.widget.ViewPager
import com.example.videostreamingapp.R
import com.example.videostreamingapp.friends.ViewPagerFragmentAdapter
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.tabs.TabLayout

class AllUsers : Fragment() {
    lateinit var messgeBtn: FloatingActionButton
    var tabLayout: TabLayout? = null
    var viewPager: ViewPager? = null

    companion object {
        fun newInstance() = AllUsers()
    }

    private lateinit var viewModel: AllUsersViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view:View =  inflater.inflate(R.layout.all_users_fragment, container, false)

        val tabLayout = view.findViewById<TabLayout>(R.id.pagerTabsLayout)
        val viewPager = view.findViewById<ViewPager>(R.id.slidingViewPager)



        viewPager.adapter = ViewPagerFragmentAdapter(childFragmentManager)
        tabLayout.setupWithViewPager(viewPager)

     return view
    }



}