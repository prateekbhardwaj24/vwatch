package com.example.videostreamingapp.bottomnavfragment.home.hometab.live

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.videostreamingapp.model.LiveModel

import com.example.videostreamingapp.repo.Repository

class LiveViewModel : ViewModel() {

    private val repository = Repository()

    fun getLiveRooms():MutableLiveData<ArrayList<LiveModel>>{
        return repository.getLiveRooms()
    }

}