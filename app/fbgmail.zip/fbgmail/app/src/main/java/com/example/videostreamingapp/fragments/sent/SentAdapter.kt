package com.example.videostreamingapp.fragments.sent

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.videostreamingapp.fragments.followers.FollowPageModel
import com.example.videostreamingapp.R

class SentAdapter: RecyclerView.Adapter<SentAdapter.MyViewHolder>() {
    private var allUsersList: ArrayList<FollowPageModel> = ArrayList()
    private lateinit var context: Context
    private lateinit var sentViewModel: SentViewModel

    fun addUserOnReferenceScreen(
        context: Context,
        userList: ArrayList<FollowPageModel>,
        sentViewModel: SentViewModel
    ) {
        this.allUsersList = userList
        this.context = context
        this.sentViewModel = sentViewModel
        notifyDataSetChanged()
    }

    class MyViewHolder(itemView:View):RecyclerView.ViewHolder(itemView) {
        var userName: TextView
        var userFullName: TextView
        var followBtn: Button
        var declineBtn: Button

        var imageView: ImageView


        init {
            userName = itemView.findViewById(R.id.uName)
            userFullName = itemView.findViewById(R.id.uFullName)
            followBtn = itemView.findViewById(R.id.followBtn)
            imageView = itemView.findViewById(R.id.uImage)
            declineBtn = itemView.findViewById(R.id.declineBtn)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val view =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.follower_page_layout, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val data = allUsersList.get(position)
        holder.userName.text = data.uname
        holder.userFullName.text = data.name
        Glide.with(context).load(data.imageUri).into(holder.imageView)

        var status = checkStatusAndChangeButton(data)
        if (status.equals("SENT")) {
            holder.declineBtn.visibility = View.GONE
            holder.followBtn.text = status
            holder.followBtn.isEnabled = false
        }

        holder.followBtn.setOnClickListener {
            runFunction(status, data.uid,position)

        }
        holder.declineBtn.setOnClickListener {
            runFunction("DECLINE", data.uid, position)
        }
    }


    private fun runFunction(status: String, uid: String, position: Int) {
        if (status.equals("SENT")) {
//request sent by me

        }
    }







    private fun checkStatusAndChangeButton(data: FollowPageModel): String {
        var result: String
        if (data.friendStatus.equals("sent")) {
            result = "SENT"
        } else {
            result = "SENT"
        }
        return result
    }

    override fun getItemCount(): Int {
        return allUsersList.size
    }
}