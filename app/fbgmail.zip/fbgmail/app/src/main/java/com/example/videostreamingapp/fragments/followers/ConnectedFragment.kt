package com.example.videostreamingapp.fragments.followers

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.example.videostreamingapp.*


class ConnectedFragment : Fragment() {
    lateinit var referenceRv: RecyclerView
    lateinit var connectedAdapter: ConnectedAdapter
    lateinit var connectedViewModel: ConnectedViewModel
    var userList:ArrayList<FollowPageModel> = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val views:View = inflater.inflate(R.layout.fragment_connected, container, false)

        connectedViewModel = ViewModelProvider(
            this
        ).get(ConnectedViewModel::class.java)


        referenceRv = views.findViewById(R.id.referncePageRv)

        referenceRv.layoutManager = LinearLayoutManager(requireContext())

        val swipeRefreshLayout = views.findViewById<SwipeRefreshLayout>(R.id.sentSwipeReferes)
        swipeRefreshLayout.setOnRefreshListener{

            // This line is important as it explicitly refreshes only once
            // If "true" it implicitly refreshes forever
            userList.clear()
            getListAccToTitle("follower",swipeRefreshLayout)
            referenceRv.adapter = connectedAdapter

        }

        connectedAdapter = ConnectedAdapter()
        getListAccToTitle("follower", swipeRefreshLayout)
        referenceRv.adapter = connectedAdapter
        return views
    }

    override fun onResume() {
        super.onResume()

    }
    private fun getListAccToTitle(title: String?, swipeRefreshLayout: SwipeRefreshLayout){
        if (userList.isNullOrEmpty()){
            swipeRefreshLayout.isRefreshing = false
        }
        connectedViewModel.fetchListAccordingToTitle(title).observe(requireActivity(), Observer {
                list->

            list?.let {
//                userList.addAll(list)
                // referencePageAdapter.addUserOnReferenceScreen(this,list,dashboardViewModel)
                connectedViewModel.fetchUserDataFromId(list, title!!).observe(requireActivity(), Observer {
                        dataList->
                    userList = dataList
                    connectedAdapter.addUserOnReferenceScreen(requireContext(),userList,connectedViewModel)
                    swipeRefreshLayout.isRefreshing = false
                })
            }
        })
    }

}