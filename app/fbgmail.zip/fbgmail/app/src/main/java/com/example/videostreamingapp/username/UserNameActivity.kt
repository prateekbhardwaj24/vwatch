package com.example.videostreamingapp.username

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.videostreamingapp.friends.DashBoardActivity
import com.example.videostreamingapp.loginwithgmail.LoginViewModel

import com.example.videostreamingapp.R
import com.example.videostreamingapp.databinding.ActivityUserNameBinding
import com.example.videostreamingapp.mainscreen.MainScreenActivity


class UserNameActivity : AppCompatActivity() {
    lateinit var loginViewModel: LoginViewModel
    lateinit var userNameBindig: ActivityUserNameBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_user_name)

        loginViewModel = ViewModelProvider(
            this
        ).get(LoginViewModel::class.java)

        userNameBindig = DataBindingUtil.setContentView(this, R.layout.activity_user_name)


        userNameBindig.userNameInputBind = loginViewModel

        userNameBindig.doneButton.setOnClickListener {
            loginViewModel.insertUserData(userNameBindig.userNameInput.text.toString()).observe(this, Observer {
                if (it){
                    Log.d("123check", "dataif: " +" $it")
                    val intent = Intent(this, MainScreenActivity::class.java)
                    startActivity(intent)
                }else{
                    Log.d("123check", "data: " +" blnk")

                }
            })
        }

    }
}